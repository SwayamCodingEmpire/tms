import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DynamicTableEditableComponent } from './dynamic-table-editable.component';

describe('DynamicTableEditableComponent', () => {
  let component: DynamicTableEditableComponent;
  let fixture: ComponentFixture<DynamicTableEditableComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [DynamicTableEditableComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DynamicTableEditableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
