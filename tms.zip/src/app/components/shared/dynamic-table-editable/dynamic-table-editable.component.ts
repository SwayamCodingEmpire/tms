import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-dynamic-table-editable',
  standalone: false,
  templateUrl: './dynamic-table-editable.component.html',
  styleUrl: './dynamic-table-editable.component.scss'
})
export class DynamicTableEditableComponent {
  @Input() hyperLinkColumns: string[] = []; // Columns that should be hyperlinked

  @Input() expandableColumns: string[] = []; // Columns that should be expandable
  @Input() columns: string[] = [];
  @Input() data: any[] = [];

  sortColumn: string | null = null;
  sortOrder: 'asc' | 'desc' = 'asc';
  sortedData: any[] = [];

  ngOnInit() {
      this.sortedData = [...this.data]; // Initialize with original data
      console.log('Sorted Data:', this.sortedData);
      console.log('Expandable Columns:', this.expandableColumns);

  }


  expandedRows: { [key: number]: { completed?: boolean; progress?: boolean } } = {};

  toggleExpand(index: number, type: 'completed' | 'progress', event: Event): void {
    event.preventDefault(); // Prevent page reload on clicking anchor
    if (!this.expandedRows[index]) {
      this.expandedRows[index] = {};
    }
    this.expandedRows[index][type] = !this.expandedRows[index][type]; // Toggle visibility
  }

  showPopup = false;
  expandedTopics: string[] = [];

  openPopup(topics: any) {
    if (typeof topics === 'string') {
      this.expandedTopics = topics.split(', ');
    } else if (Array.isArray(topics)) {
      this.expandedTopics = topics; // If it's already an array, use it directly
    } else {
      this.expandedTopics = []; // Handle unexpected types gracefully
    }
    this.showPopup = true;
  }


  onDelete(row: any) {
    console.log('Delete clicked for:', row);
    // Add your delete logic here
  }

  editTopics(index: number, column: string) {
    // Logic to handle topic editing inside row
  }


  closePopup() {
    this.showPopup = false;
  }

  sortData(column: string, order: 'asc' | 'desc') {
    this.sortColumn = column;
    this.sortOrder = order;

    this.sortedData = [...this.data].sort((a, b) => {
      const valueA = a[column] || '';
      const valueB = b[column] || '';

      if (typeof valueA === 'number' && typeof valueB === 'number') {
        return order === 'asc' ? valueA - valueB : valueB - valueA;
      } else {
        return order === 'asc' ? valueA.localeCompare(valueB) : valueB.localeCompare(valueA);
      }
    });
  }

  validColumnForInsideEdit(column: string): boolean {
    return column!='Description' && column!=='Topics';
  }

  getExpandableText(value: any): string[] {
    if (!value) return []; // Handle null or undefined
    if (Array.isArray(value)) return value.slice(0, 2); // If it's already an array, return first 2 items

    const stringValue = String(value); // Convert to string if necessary
    return stringValue.split(',').map(item => item.trim()).slice(0, 2);
  }


  getRemainingCount(value: any): number {
    console.log("Checking remaining count for:", value);
    if (!value) return 0;
    if (Array.isArray(value)) return Math.max(value.length - 2, 0);

    const stringValue = String(value);
    const items = stringValue.split(',').map(item => item.trim());
    console.log("Total items:", items.length, "Remaining:", Math.max(items.length - 2, 0));
    return Math.max(items.length - 2, 0);
  }


  expandRow(row: any, column: string) {
    alert(`Full data: ${row[column]}`);
  }

  editingRows = new Set<number>();
  editedRow: any = {};

  onEdit(index: number, row: any) {
    this.editedRow[index] = { ...row }; // Store original row for cancel functionality
    this.editingRows.add(index);
  }

  saveRow(index: number) {
    this.editingRows.delete(index);
  }

  cancelEdit(index: number) {
    this.sortedData[index] = { ...this.editedRow[index] }; // Restore original row
    this.editingRows.delete(index);
  }

}
