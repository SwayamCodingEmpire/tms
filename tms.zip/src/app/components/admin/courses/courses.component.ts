import { Component, Renderer2 } from '@angular/core';

@Component({
  selector: 'app-courses',
  standalone: false,
  templateUrl: './courses.component.html',
  styleUrl: './courses.component.scss'
})
export class CoursesComponent {

  searchTerm: string = '';
  editingIndex: number | null = null;

  constructor(private renderer: Renderer2) {

  }


  ngOnInit() {
    this.renderer.setStyle(document.body, 'background-color', '#f3faff');
  }

  tableColumns = ['Code', 'Course Name', 'Theory Time', 'Practice Time', 'Description', 'Topics'];
  hyperLinkColumns = ['Code', 'Description'];
  expandableColumns = ['Topics'];



  courses = [

    { 'Code': '2E2124', 'Course Name': 'Data Visualization', 'Theory Time': '3 hrs', 'Practice Time': '3 hrs', 'Description': 'Bar Chart Data...', 'Topics': ['Bar Chart Data Visualization', 'Time Series Data Visualization', '+2 more'] },
    { 'Code': '3F2126', 'Course Name': 'Error Handling', 'Theory Time': '2 hrs', 'Practice Time': '2 hrs', 'Description': 'Variables and...', 'Topics': ['Variables and operators', 'External file', 'Sessions and Cookies', '+5 more'] },
    { 'Code': '1F2125', 'Course Name': 'Data Visualization', 'Theory Time': '3 hrs', 'Practice Time': '3 hrs', 'Description': 'Analytics, Data...', 'Topics': ['Analytics', 'Data Visualization', 'Dashboards'] },
    { 'Code': '1K2125', 'Course Name': 'Excel to my SQL', 'Theory Time': '3 hrs', 'Practice Time': '3 hrs', 'Description': 'Excel to my SQL...', 'Topics': ['Excel to my SQL', 'Meta'] },
    { 'Code': '3K2128', 'Course Name': 'Dashboards', 'Theory Time': '3 hrs', 'Practice Time': '3 hrs', 'Description': 'Analytics, Data...', 'Topics': ['Analytics', 'Data Visualization', 'Dashboards'] },
    { 'Code': '1J2124', 'Course Name': 'Machine Learning', 'Theory Time': '4 hrs', 'Practice Time': '4 hrs', 'Description': 'Machine Learning...', 'Topics': ['Machine Learning', 'Big Data', 'Business Acumen', '+5 more'] },
    { 'Code': '1N2125', 'Course Name': 'JavaScript', 'Theory Time': '5 hrs', 'Practice Time': '5 hrs', 'Description': 'JavaScript Basics...', 'Topics': ['Excel to my SQL', 'Meta','likun','swayam'] },
  ];


  get filteredCourses() {
    if (!this.searchTerm.trim()) {
      return this.courses;
    }
    return this.courses.filter(course =>
      course['Course Name'].toLowerCase().includes(this.searchTerm.toLowerCase()) ||
      course['Code'].toLowerCase().includes(this.searchTerm.toLowerCase())
    );
  }

  editDescription(index: number) {
    this.editingIndex = index;
  }

  saveDescription() {
    this.editingIndex = null;
  }

  cancelEdit() {
    this.editingIndex = null;
  }

}
